not all repos will have somethign we need, if code looks not up to standard, omit from our strategy and remove form this list.

exmaine each system for it unique beefits and add those to our own uniqe roadmap.

ensure you examine all repos in deprth so we don't miss out on some great features.

Once you have completed the scan, compile alist of the features we will add on top of bolt.diy which will be our base tech built under our new UI or our new UI built over bolt.

cret a strategic roadmap priortising must have functions first, and then the rest into managable sprints.

Output the stratgey roadmap - we can discuss then.

https://github.com/cline/cline

https://github.com/stackblitz-labs/bolt.diy
https://stackblitz-labs.github.io/bolt.diy/

https://github.com/RooVetGit/Roo-Code

https://github.com/Oneirocom/Magick

https://github.com/Exafunction/windsurf.vim

https://github.com/TransformerOptimus/SuperAGI

https://github.com/eylonmiz/react-agent

https://github.com/TabbyML/tabby

**IMPORTANT**
https://github.com/microsoft/UFO

https://github.com/nicepkg/gpt-runner

https://github.com/The-Creator-AI/The-Creator-AI

https://github.com/continuedev/continue

https://github.com/OthersideAI/self-operating-computer

https://github.com/Aider-AI/aider

https://github.com/letta-ai/letta

https://github.com/All-Hands-AI/OpenHands

https://github.com/crewAIInc/crewAI

https://github.com/HumanSignal/Adala

https://github.com/entropy-research/Devon

https://github.com/microsoft/JARVIS

https://github.com/jbexta/AgentPilot

https://github.com/OpenBMB/AgentVerse

https://github.com/erik-megarad/beebot

https://github.com/seahyinghang8/blinky

https://github.com/xeol-io/bumpgen

**IMPORTANT**
https://github.com/OpenBMB/ChatDev

https://github.com/ur-whitelab/chemcrow-public

https://github.com/codefuse-ai/codefuse-chatbot