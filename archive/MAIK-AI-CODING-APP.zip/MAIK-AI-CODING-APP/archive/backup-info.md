ok thank you,

So here some background info;

https://replit.com/@heaventreedesig/MAIK-AI-CODING-APP#attached_assets/guide-repos.md

https://replit.com/@heaventreedesig/MAIK-AI-CODING-APP#attached_assets/Bolt_DIY_Super_Prompt_Blueprint.md

https://replit.com/@heaventreedesig/MAIK-AI-CODING-APP#archive/PROJECT-DOCS/DOCUMENTATION_SYSTEM_REVIEW.md

https://replit.com/@heaventreedesig/MAIK-AI-CODING-APP#archive/Handovers/MAIK-IDE-Handover-20240416.md

https://replit.com/@heaventreedesig/MAIK-AI-CODING-APP#archive/Handovers/MAIK-IDE-Handover-20240417.md

https://replit.com/@heaventreedesig/MAIK-AI-CODING-APP#archive/project_management/MAIK_IDE_COMPREHENSIVE_STRATEGY.md

https://replit.com/@heaventreedesig/MAIK-AI-CODING-APP#archive/project_management/MAIK_IDE_ROADMAP.md

https://replit.com/@heaventreedesig/MAIK-AI-CODING-APP#archive/project_management/MAIK_IDE_TASKS.md

https://replit.com/@heaventreedesig/MAIK-AI-CODING-APP#archive/project_management/UI_GENERATION_STRATEGY.md