This is a fork for my hosted version at
https://bolt.myaibuilt.app/
With small changes I need for hosting it

Main Repository is Bolt.diy here https://github.com/stackblitz-labs/bolt.diy as I joined efforts to contribute and work together with others there

![image](https://github.com/user-attachments/assets/fa3517a7-0f7f-460e-a19b-ef7d4617201f)
