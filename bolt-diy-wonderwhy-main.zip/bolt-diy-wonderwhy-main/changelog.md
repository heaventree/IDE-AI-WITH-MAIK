# Release v0.0.3

### 🔄 Changes since v0.0.2

#### 🐛 Bug Fixes

- Prompt Enhance


#### 📚 Documentation

- miniflare error knowledge


#### 🔧 Chores

- adding back semantic pull pr check for better changelog system
- update commit hash to 1e72d52278730f7d22448be9d5cf2daf12559486
- update commit hash to 282beb96e2ee92ba8b1174aaaf9f270e03a288e8


#### 🔍 Other Changes

- Merge remote-tracking branch 'upstream/main'
- Merge pull request #781 from thecodacus/semantic-pull-pr
- miniflare and wrangler error
- simplified the fix
- Merge branch 'main' into fix/prompt-enhance


**Full Changelog**: [`v0.0.2..v0.0.3`](https://github.com/stackblitz-labs/bolt.diy/compare/v0.0.2...v0.0.3)
