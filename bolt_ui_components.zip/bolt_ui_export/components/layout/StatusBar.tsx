import React, { useEffect, useState } from 'react';
import { 
  Zap, Clock, GitBranch, Circle, 
  FileCode, Bell, Wifi, Cpu, 
  CheckCircle, Terminal, MessageSquare, Edit
} from 'lucide-react';
import { useWebSocket } from '../../contexts/WebSocketContext';

interface StatusBarProps {
  currentMode?: 'editor' | 'prompt';
}

interface StatusItemProps {
  icon: React.ReactNode;
  text: string;
  title?: string;
  className?: string;
}

const StatusItem: React.FC<StatusItemProps> = ({ icon, text, title, className = '' }) => (
  <div className={`statusbar-item ${className}`} title={title}>
    <div className="statusbar-item-icon">{icon}</div>
    <div className="statusbar-item-text">{text}</div>
  </div>
);

const StatusBar: React.FC<StatusBarProps> = ({ currentMode = 'editor' }) => {
  const { connected } = useWebSocket();
  const [time, setTime] = useState(new Date().toLocaleTimeString());
  
  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date().toLocaleTimeString());
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);
  
  return (
    <div className="statusbar-container">
      {/* Left status items */}
      <div className="statusbar-left">
        <StatusItem 
          icon={<Circle size={8} fill={connected ? 'currentColor' : 'none'} />}
          text={connected ? 'Connected' : 'Disconnected'}
          className={connected ? 'success' : 'muted'}
        />
        
        <StatusItem 
          icon={currentMode === 'editor' ? <Edit size={12} /> : <MessageSquare size={12} />}
          text={currentMode === 'editor' ? "Editor Mode" : "Prompt Mode"}
          className={currentMode === 'prompt' ? 'info' : ''}
        />
        
        <StatusItem 
          icon={<FileCode size={12} />}
          text="TypeScript"
        />
        
        <StatusItem 
          icon={<Terminal size={12} />}
          text="main.ts"
        />
      </div>
      
      {/* Right status items */}
      <div className="statusbar-right">
        <StatusItem 
          icon={<GitBranch size={12} />}
          text="main"
          title="Git branch"
        />
        
        <StatusItem 
          icon={<Cpu size={12} />}
          text="98%"
          title="Performance: 98% efficient"
        />
        
        <StatusItem 
          icon={<CheckCircle size={12} color="#0acf97" />}
          text="All good"
          title="All systems normal"
          className="success"
        />
        
        <StatusItem 
          icon={<Clock size={12} />}
          text={time}
          title="Current time"
        />
      </div>
    </div>
  );
};

export default StatusBar;