# {{PROJECT_NAME}} - Architecture

## System Overview

{{ARCHITECTURE_OVERVIEW}}

## Architectural Principles

- {{ARCHITECTURE_PRINCIPLE_1}}
- {{ARCHITECTURE_PRINCIPLE_2}}
- {{ARCHITECTURE_PRINCIPLE_3}}
- {{ARCHITECTURE_PRINCIPLE_4}}

## High-Level Architecture

